import React, { useEffect, useRef, useState } from "react";
import styles from "../../styles/AlbumPage.module.scss";
import { IAlbum } from "../../types/albums";
import EditIcon from "@material-ui/icons/Edit";
import { useDispatch } from "react-redux";
import { NextThunkDispatch } from "../../store";
import { updateAlbum } from "../../store/actions-creators/albums";
import { TFieldRef } from "../../types/jointTypes";

interface AlbumDescriptionProps {
  thisAlbum: IAlbum;
  setThisAlbum: Function;
}
export const AlbumDescription: React.FC<AlbumDescriptionProps> = ({
  thisAlbum,
  setThisAlbum,
}) => {
  const dispatch = useDispatch() as NextThunkDispatch;
  const nameRef = useRef<HTMLSpanElement>(null);
  const artistRef = useRef<HTMLSpanElement>(null);
  const [currentField, setCurrentField] = useState<TFieldRef>(null);
  const [isEditable, setIsEditable] = useState(false);

  useEffect(() => {
    if (isEditable) {
      currentField.current.focus();
    }
  }, [isEditable]);

  const handleOnBlurAlbumUpdate = async (
    fieldRef: TFieldRef,
    field: string
  ) => {
    const fieldContent = fieldRef.current.textContent;
    if (thisAlbum[field] === fieldContent) {
      setIsEditable(false);
      return;
    }

    await dispatch(
      await updateAlbum(thisAlbum._id, {
        [field]: fieldRef.current.textContent,
      })
    );
    setIsEditable(false);
    setCurrentField(null);
    setThisAlbum({
      ...thisAlbum,
      [field]: fieldRef.current.textContent.trim(),
    });
  };

  const handleClickOnEditIcon = (fieldRef: TFieldRef) => {
    setCurrentField(fieldRef);
    setIsEditable(true);
  };

  return (
    <div style={{ margin: 30 }}>
      <h2>
        Name:{" "}
        <span
          className={`${styles.spanField}${
            isEditable ? " " + styles.isEditable : ""
          }`}
          ref={nameRef}
          onBlur={() => handleOnBlurAlbumUpdate(nameRef, "name")}
          contentEditable={isEditable}
        >
          {thisAlbum.name}
        </span>{" "}
        <EditIcon
          onClick={() => handleClickOnEditIcon(nameRef)}
          className={styles.editIcon}
        />
      </h2>
      <h2>
        Artist:{" "}
        <span
          ref={artistRef}
          contentEditable={isEditable}
          onBlur={() => handleOnBlurAlbumUpdate(artistRef, "author")}
          className={`${styles.spanField}${
            isEditable ? " " + styles.isEditable : ""
          }`}
        >
          {thisAlbum.author}
        </span>{" "}
        <EditIcon
          onClick={() => handleClickOnEditIcon(artistRef)}
          className={styles.editIcon}
        />
      </h2>
      <h2>Tracks: {thisAlbum.tracks.length}</h2>
    </div>
  );
};
