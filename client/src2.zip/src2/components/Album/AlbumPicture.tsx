import React, { useEffect, useState } from "react";
import { IAlbum } from "../../types/albums";
import styles from "../../styles/AlbumPage.module.scss";
import PhotoLibraryIcon from "@material-ui/icons/PhotoLibrary";
import { FileUpload } from "../../components/FileUploader";
import { NextThunkDispatch } from "../../store";
import { useDispatch } from "react-redux";
import { updateAlbum } from "../../store/actions-creators/albums";

interface AlbumPictureProps {
  thisAlbum: IAlbum;
}
export const AlbumPicture: React.FC<AlbumPictureProps> = ({ thisAlbum }) => {
  const [picture, setPicture] = useState<File>(null);
  const [globTrackPicture, setGlobTrackPicture] = useState(null);
  const dispatch = useDispatch() as NextThunkDispatch;

  const handlePictureUpdate = async (picture) => {
    await dispatch(
      await updateAlbum(thisAlbum._id, {
        picture,
      })
    );
  };

  useEffect(() => {
    if (picture) {
      handlePictureUpdate(picture);
    }
  }, [picture]);

  return (
    <FileUpload
      setFile={setPicture}
      setGlobImage={setGlobTrackPicture}
      accept="image/*"
    >
      <div className={styles.mainCoverContainer}>
        <div className={styles.iconContainer}>
          <PhotoLibraryIcon className={styles.insertPhotoIcon} />
        </div>
        <img
          src={
            globTrackPicture
              ? globTrackPicture
              : "http://localhost:5000/" + thisAlbum.picture
          }
          alt="album picture"
        />
      </div>
    </FileUpload>
  );
};
